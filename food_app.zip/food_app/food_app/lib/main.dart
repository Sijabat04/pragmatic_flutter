import 'package:flutter/material.dart';
import 'screens/login_page.dart'; // Import halaman login yang sudah dibuat

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Food App SQL',
      debugShowCheckedModeBanner: false, // Menghilangkan banner debug
      theme: ThemeData(
        primarySwatch: Colors.orange,
        useMaterial3: true,
        fontFamily: 'Poppins', // Opsional: jika kamu menambahkan font custom
      ),
      // Halaman pertama yang akan dibuka
      home: LoginPage(), 
    );
  }
}