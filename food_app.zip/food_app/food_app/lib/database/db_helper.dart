import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

class DbHelper {
  static Database? _db;

  // Method initDb (Tetap ada untuk persiapan jika nanti dijalankan di HP)
  Future<Database?> initDb() async {
    if (kIsWeb) return null; 
    
    String path = join(await getDatabasesPath(), 'food.db');
    return await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute(
          'CREATE TABLE foods (id INTEGER PRIMARY KEY, name TEXT, price TEXT, category TEXT, image TEXT)');
      
      // Data untuk di Android/iOS HP
      await db.insert('foods', {
        'name': 'Nasi Goreng', 
        'price': '20.000', 
        'category': 'Populer',
        'image': 'https://bit.ly/3vL9vUu'
      });
    });
  }

  // Method getFoods dengan data link gambar untuk Chrome Web
  Future<List<Map<String, dynamic>>> getFoods() async {
    if (kIsWeb) {
      // Data dummy menggunakan link internet agar langsung muncul di Chrome
      return [
        {
          'name': 'Nasi Goreng Special', 
          'price': '20.000', 
          'image': 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?q=80&w=500'
        },
        {
          'name': 'Ayam Bakar Honey', 
          'price': '25.000', 
          'image': 'https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?q=80&w=500'
        },
        {
          'name': 'Es Teh Manis', 
          'price': '8.000', 
          'image': 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?q=80&w=500'
        },
        {
          'name': 'Es Jeruk Segar', 
          'price': '10.000', 
          'image': 'https://images.unsplash.com/photo-1613478223719-2ab802602423?q=80&w=500'
        },
      ];
    }

    _db ??= await initDb();
    return await _db!.query('foods');
  }
}